# CopyPlanetFactory

# 星球蓝图

按“复制C”复制当前星球的全部建筑

然后到另一个星球按“黏贴V”能够复制建筑

暂时没有碰撞检测，只有重叠检测

保存的数据文件在 Dyson Sphere Program\BepInEx\config\PlanetFactoryData

Press "复制C" to copy all the buildings on the current planet

Then go to another planet and press "黏贴V" to copy the building

The test version has no collision detection for the time being, only overlap detection

data file in Dyson Sphere Program\BepInEx\config\PlanetFactoryData


### Installation

1. Install BepInEx
3. Then drag Tp.dll into steamapps/common/Dyson Sphere Program/BepInEx/plugins


### 安装

1. 先安装 BepInEx框架
3. 将CopyPlanetFactory.dll拖到 steamapps/common/Dyson Sphere Program/BepInEx/plugins文件夹内
